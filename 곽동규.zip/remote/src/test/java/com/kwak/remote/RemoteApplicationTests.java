package com.kwak.remote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RemoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
